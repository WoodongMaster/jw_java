package day09;

public class 테스트 {

	public static void main(String[] args) {
		CardPack c = new CardPack();
		
	}

}
