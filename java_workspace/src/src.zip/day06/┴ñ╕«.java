package day06;

public class 정리 {

	public static void main(String[] args) {
		/* 정리
		 * 
		 * 1. 변수
		 *- 일반변수(지역변수, 기본형변수)
		 * 
		 */

	}

}
