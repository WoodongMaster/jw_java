package day01;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World"); //ln 포함 -> 줄바꿈, ln 미포함 -> 붙혀서
		System.out.println("가나다라마바사"); // ctrl + space bar = 자동완성
		System.out.println("123456");
		
	}

}
