package S2day01;

public interface Program {
abstract void printStudent();
abstract void insertStudent();
abstract void searchStudent();
abstract void registerSubject();
abstract void deleteSubject();
}


