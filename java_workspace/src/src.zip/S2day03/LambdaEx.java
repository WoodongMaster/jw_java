package S2day03;

import java.util.ArrayList;

public class LambdaEx {

	public static void main(String[] args) {
		// Lambda expression : 람다식
		// 함수형 프로그래밍(Funtionnal programming : FP)
		// 순수한 함수를 구현하고 호출함으로써 외부자료에 부수적인 영향을 끼치지않음
		System.out.println(add(3,5));
		
		ArrayList<Integer> number = new ArrayList<>();
		number.add(10);
		number.add(20);
		number.add(5);
		number.add(30);
		number.add(40);
		number.add(50);
		
		for(Integer i : number) {
			System.out.print(i+" ");
		}
		System.out.println();
		System.out.println("==========람다식==========");
		
		number.forEach((n)->{
			System.out.print(n+" ");
		});
		
		System.out.println();
		number.forEach(System.out::println);
		
		System.out.println("--number list 총 개수 --");
		System.out.println(number.stream().count());
	}

	public static int add(int x, int y) {
		return x+y;
	}

}

// (int x, int y) -> {return x+y}
// int x -> {return x+y}