package S2day02;

public interface AL_Program {
abstract void printStudent();
abstract void insertStudent();
abstract void searchStudent();
abstract void registerSubject();
abstract void deleteSubject();
}
