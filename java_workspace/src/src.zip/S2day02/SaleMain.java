package S2day02;

public class SaleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
