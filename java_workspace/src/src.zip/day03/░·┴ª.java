package day03;

public class 과제 {

	public static void main(String[] args) {
		for(char i='A'; i<='Z'; i++) 
		{
			for(char j='A'; j<=i; j++) 
			{
				System.out.print(j);
			}
			System.out.println();
		}
		System.out.println();
	}

}
