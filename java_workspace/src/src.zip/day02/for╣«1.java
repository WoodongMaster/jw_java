package day02;

public class for문1 {

	public static void main(String[] args) {
		/*
		int sum=0;
		int i;
		System.out.println("SUM의 값 : "+sum);
		for(i=0; i<11; i++) {
			sum=sum+i;
		}
		System.out.println("SUM의 값 : "+sum);
		System.out.println("i의 값 : "+i);
		 */
		int sum=0;
		for(int a=0; a<11; a++) {
			sum+=a;
			
			}
		System.out.println(sum);
		}
	
	
	
	}

