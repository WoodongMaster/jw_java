package day02;

public class 자료형변환 {

	public static void main(String[] args) {
		// casting

	}

}
